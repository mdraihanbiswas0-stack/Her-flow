plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jonaki.search"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jonaki.search"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    // One fixed key for every build, so a newer APK always installs over the older one.
    // (Personal-use key. For Play Store publishing create your own keystore.)
    signingConfigs {
        create("omni") {
            storeFile = file("omnifinder.keystore")
            storePassword = "omnifinder"
            keyAlias = "omnifinder"
            keyPassword = "omnifinder"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("omni")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("omni")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
