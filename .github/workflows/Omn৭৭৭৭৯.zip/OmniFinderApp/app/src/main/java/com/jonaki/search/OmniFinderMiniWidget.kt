package com.jonaki.search

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/** Compact 4x1 search-bar widget: logo | search field | camera | voice. */
class OmniFinderMiniWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(context.packageName, R.layout.omnifinder_mini)
            v.setOnClickPendingIntent(R.id.omni_logo, omniPendingIntent(context, "search"))
            v.setOnClickPendingIntent(R.id.omni_search, omniPendingIntent(context, "search"))
            v.setOnClickPendingIntent(R.id.omni_camera, omniPendingIntent(context, "camera"))
            v.setOnClickPendingIntent(R.id.omni_voice, omniPendingIntent(context, "voice"))
            manager.updateAppWidget(id, v)
        }
    }
}
