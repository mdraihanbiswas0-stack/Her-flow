package com.jonaki.search

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/** Builds the PendingIntent that opens OmniFinder in a given mode (search, camera, voice, files, apps, contacts, web). */
internal fun omniPendingIntent(ctx: Context, mode: String): PendingIntent {
    val i = Intent(ctx, MainActivity::class.java).apply {
        action = Intent.ACTION_VIEW
        data = Uri.parse("omnifinder://widget/$mode")
        putExtra(MainActivity.EXTRA_MODE, mode)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
    return PendingIntent.getActivity(
        ctx, mode.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

/**
 * 4x2 home-screen widget — a copy of the in-app search bar:
 * logo | search field | camera | voice, and the tool strip underneath.
 */
class OmniFinderWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(context.packageName, R.layout.omnifinder_widget)
            v.setOnClickPendingIntent(R.id.omni_logo, omniPendingIntent(context, "search"))
            v.setOnClickPendingIntent(R.id.omni_search, omniPendingIntent(context, "search"))
            v.setOnClickPendingIntent(R.id.omni_camera, omniPendingIntent(context, "camera"))
            v.setOnClickPendingIntent(R.id.omni_voice, omniPendingIntent(context, "voice"))
            v.setOnClickPendingIntent(R.id.t_camera, omniPendingIntent(context, "camera"))
            v.setOnClickPendingIntent(R.id.t_voice, omniPendingIntent(context, "voice"))
            v.setOnClickPendingIntent(R.id.t_files, omniPendingIntent(context, "files"))
            v.setOnClickPendingIntent(R.id.t_apps, omniPendingIntent(context, "apps"))
            v.setOnClickPendingIntent(R.id.t_contacts, omniPendingIntent(context, "contacts"))
            v.setOnClickPendingIntent(R.id.t_web, omniPendingIntent(context, "web"))
            manager.updateAppWidget(id, v)
        }
    }
}
