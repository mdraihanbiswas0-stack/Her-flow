package com.earflow.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var list: ListView
    private var tab = 0
    private var files = listOf<File>()
    private var player: MediaPlayer? = null

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            ContextCompat.startForegroundService(this, Intent(this, ScreenRecordService::class.java).apply {
                action = "START"; putExtra("code", r.resultCode); putExtra("data", r.data)
            })
            moveTaskToBack(true)
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("ef", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(TextView(this).apply { text = "ইয়ার-ফ্লো"; textSize = 26f })
        root.addView(Switch(this).apply {
            text = "অটো কল রেকর্ড"
            isChecked = prefs.getBoolean("auto", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("auto", on).apply()
                val i = Intent(this@MainActivity, CallRecordService::class.java).setAction(if (on) "IDLE" else "QUIT")
                ContextCompat.startForegroundService(this@MainActivity, i)
            }
        })
        root.addView(btn("পারমিশন সেটআপ") { setupDialog() })
        root.addView(btn("🔴 স্ক্রিন রেকর্ড শুরু") { startScreen() })
        root.addView(btn("⚙ সেটিংস") { settingsDialog() })

        val tabs = LinearLayout(this)
        tabs.addView(btn("কল রেকর্ডিং") { tab = 0; refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(btn("ভিডিও") { tab = 1; refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)

        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (prefs.getBoolean("auto", false))
            ContextCompat.startForegroundService(this, Intent(this, CallRecordService::class.java).setAction("IDLE"))

        list.setOnItemClickListener { _, _, pos, _ ->
            val f = files[pos]
            if (tab == 1) startActivity(Intent(this, EditorActivity::class.java).putExtra("path", f.absolutePath))
            else { player?.release(); player = MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start() } }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this).setMessage("মুছে ফেলবেন?")
                .setPositiveButton("হ্যাঁ") { _, _ -> files[pos].delete(); refresh() }
                .setNegativeButton("না", null).show()
            true
        }
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onDestroy() { player?.release(); super.onDestroy() }

    private fun refresh() {
        val dir = File(getExternalFilesDir(null), if (tab == 0) "calls" else "videos")
        files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            files.map { it.nameWithoutExtension.replace("_", "  ") })
    }

    private fun startScreen() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে ওভারলে পারমিশন দিন", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 2)
        projLauncher.launch((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
    }

    private fun setupDialog() {
        val items = arrayOf("১. রানটাইম পারমিশন (ফোন, কল লগ, মাইক, কন্টাক্ট)", "২. ওভারলে (ভাসমান বিন্দু)",
            "৩. ব্যাটারি অপটিমাইজেশন বন্ধ", "৪. অ্যাক্সেসিবিলিটি চালু (কলে মাইকের জন্য)")
        AlertDialog.Builder(this).setTitle("সব ধাপ করুন").setItems(items) { _, i ->
            when (i) {
                0 -> ActivityCompat.requestPermissions(this, arrayOf(
                    Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.PROCESS_OUTGOING_CALLS, Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 1)
                1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                2 -> if (!(getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName))
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                3 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }.show()
    }

    private fun settingsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        fun spin(label: String, names: List<String>, vals: List<Int>, key: String, def: Int) {
            box.addView(TextView(this).apply { text = label })
            box.addView(Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
                setSelection(vals.indexOf(prefs.getInt(key, def)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        prefs.edit().putInt(key, vals[pos]).apply()
                    }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            })
        }
        fun chk(label: String, key: String, def: Boolean) = box.addView(CheckBox(this).apply {
            text = label; isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        })
        box.addView(TextView(this).apply { text = "— স্ক্রিন রেকর্ড —"; textSize = 16f })
        spin("রেজোলিউশন", listOf("720p", "1080p", "ফোনের নেটিভ"), listOf(720, 1080, 0), "quality", 1080)
        spin("FPS", listOf("30", "60"), listOf(30, 60), "fps", 60)
        spin("বিটরেট", listOf("8 Mbps", "16 Mbps", "24 Mbps"), listOf(8, 16, 24), "bitrate", 16)
        chk("মাইক্রোফোন (ভয়েস) রেকর্ড", "mic", true)
        chk("৩-২-১ কাউন্টডাউন", "countdown", true)
        chk("ভাসমান ইশারা-বিন্দু দেখান", "dot", true)
        spin("বিন্দুর রঙ", listOf("লাল", "হলুদ", "সবুজ"), listOf(0, 1, 2), "dotColor", 0)
        box.addView(TextView(this).apply { text = "— কল রেকর্ড —"; textSize = 16f; setPadding(0, dp(12), 0, 0) })
        chk("কলে অটো স্পিকার + ফুল ভলিউম", "speaker", true)
        spin("সাউন্ড বুস্ট (সর্বোচ্চ)", listOf("৪x", "৮x", "১২x", "২০x"), listOf(4, 8, 12, 20), "gain", 12)
        AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("ঠিক আছে", null).show()
    }
}
