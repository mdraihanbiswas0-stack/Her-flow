package com.earflow.app

import android.content.ContentValues
import android.media.*
import android.os.*
import android.provider.MediaStore
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max

class EditorActivity : AppCompatActivity() {
    private lateinit var path: String
    private lateinit var video: VideoView
    private var dur = 0
    private var startMs = 0
    private var endMs = 0
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        title = "ভিডিও এডিটর"
        path = intent.getStringExtra("path")!!
        MediaMetadataRetriever().also {
            it.setDataSource(path)
            dur = it.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toInt(); it.release()
        }
        endMs = dur

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        video = VideoView(this).apply { setVideoPath(path); seekTo(1) }
        root.addView(video, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val info = TextView(this)
        fun upd() { info.text = "শুরু: ${startMs / 1000.0}s   শেষ: ${endMs / 1000.0}s   (মোট ${dur / 1000.0}s)" }
        upd()
        root.addView(info)

        fun seek(label: String, init: Int, onCh: (Int) -> Unit): SeekBar {
            root.addView(TextView(this).apply { text = label })
            return SeekBar(this).apply {
                max = dur; progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { if (user) { onCh(p); upd() } }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
                root.addView(this)
            }
        }
        seek("শুরু", 0) { startMs = minOf(it, endMs - 100); video.seekTo(startMs) }
        seek("শেষ", dur) { endMs = max(it, startMs + 100) }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; root.addView(this) }
        btn("▶ নির্বাচিত অংশ প্লে") {
            video.seekTo(startMs); video.start()
            val chk = object : Runnable {
                override fun run() {
                    if (video.currentPosition >= endMs) video.pause() else if (video.isPlaying) h.postDelayed(this, 50)
                }
            }
            h.postDelayed(chk, 100)
        }
        btn("✂ ট্রিম করে নতুন ভিডিও সেভ") {
            val dst = File(File(path).parentFile, "EarFlow_trim_${System.currentTimeMillis()}.mp4")
            Toast.makeText(this, "সেভ হচ্ছে...", Toast.LENGTH_SHORT).show()
            Thread {
                try { trim(path, dst.absolutePath, startMs * 1000L, endMs * 1000L)
                    runOnUiThread { Toast.makeText(this, "সেভ হয়েছে: ${dst.name}", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "ব্যর্থ: ${e.message}", Toast.LENGTH_LONG).show() } }
            }.start()
        }
        btn("📥 গ্যালারিতে সেভ") { toGallery() }
        setContentView(root)
    }

    // রি-এনকোড ছাড়া ট্রিম (দ্রুত, কোয়ালিটি লস নেই); শুরু সবচেয়ে কাছের কী-ফ্রেমে যায়
    private fun trim(src: String, dst: String, startUs: Long, endUs: Long) {
        val ex = MediaExtractor().apply { setDataSource(src) }
        val mux = MediaMuxer(dst, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val map = HashMap<Int, Int>()
        var maxBuf = 1 shl 20
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val m = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("video/") || m.startsWith("audio/")) {
                ex.selectTrack(i); map[i] = mux.addTrack(f)
                if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxBuf = max(maxBuf, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
        }
        mux.start()
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buf = ByteBuffer.allocate(maxBuf)
        val info = MediaCodec.BufferInfo()
        var base = -1L
        while (true) {
            info.size = ex.readSampleData(buf, 0)
            if (info.size < 0) break
            val t = ex.sampleTime
            if (t > endUs) break
            if (base < 0) base = t
            info.presentationTimeUs = max(0L, t - base)
            info.flags = ex.sampleFlags
            info.offset = 0
            mux.writeSampleData(map[ex.sampleTrackIndex]!!, buf, info)
            ex.advance()
        }
        mux.stop(); mux.release(); ex.release()
    }

    private fun toGallery() {
        val f = File(path)
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EarFlow")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            Toast.makeText(this, "গ্যালারি > Movies/EarFlow এ সেভ হয়েছে", Toast.LENGTH_LONG).show()
        }
    }
}
