package com.earflow.app

import android.app.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.Intent
import android.media.*
import android.media.audiofx.AutomaticGainControl
import android.net.Uri
import android.os.*
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class CallRecordService : Service() {
    @Volatile private var running = false
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        when (intent?.action) {
            "START" -> startRec(intent.getStringExtra("number") ?: "", intent.getBooleanExtra("incoming", true))
            "STOP" -> running = false
            "QUIT" -> { running = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_STICKY
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("call", "Call recorder", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "call")
            .setContentTitle("ইয়ার-ফ্লো: অটো কল রেকর্ড চালু")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun clean(s: String) = s.replace(Regex("[^\\p{L}\\p{N}+ ]"), "_")

    private fun fileName(name: String, num: String, incoming: Boolean, time: String) =
        "${clean(name)}_${clean(num.ifEmpty { "NoNumber" })}_${if (incoming) "IN" else "OUT"}_$time.wav"

    private fun startRec(numberIn: String, incoming: Boolean) {
        if (running) return
        running = true
        val p = getSharedPreferences("ef", MODE_PRIVATE)
        val maxGain = p.getInt("gain", 12).toFloat()
        val audio = getSystemService(AudioManager::class.java)
        val oldSpeaker = audio.isSpeakerphoneOn
        val oldVol = audio.getStreamVolume(AudioManager.STREAM_VOICE_CALL)

        // অপর প্রান্তের আওয়াজ মাইকে ধরতে: স্পিকার অন + ভলিউম ম্যাক্স
        if (p.getBoolean("speaker", true)) {
            @Suppress("DEPRECATION")
            audio.isSpeakerphoneOn = true
            audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                audio.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
        }

        val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = File(getExternalFilesDir(null), "calls").apply { mkdirs() }
        val name = contactName(numberIn) ?: "Unknown"
        val file = File(dir, fileName(name, numberIn, incoming, time))

        Thread {
            val rate = 16000
            val bufSize = maxOf(AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT), rate * 2)
            var rec: AudioRecord? = null
            for (src in intArrayOf(MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.UNPROCESSED,
                MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)) {
                try {
                    val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)
                    if (r.state == AudioRecord.STATE_INITIALIZED) { rec = r; break } else r.release()
                } catch (_: Exception) {}
            }
            var total = 0L
            try {
                if (rec != null) {
                    if (AutomaticGainControl.isAvailable())
                        AutomaticGainControl.create(rec.audioSessionId)?.enabled = true
                    val raf = RandomAccessFile(file, "rw")
                    raf.setLength(0); raf.write(ByteArray(44))
                    val buf = ShortArray(bufSize / 2)
                    var gain = 1f
                    rec.startRecording()
                    while (running) {
                        val n = rec.read(buf, 0, buf.size)
                        if (n <= 0) continue
                        var peak = 1
                        for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                        // কম আওয়াজ হলে অটো গেইন বাড়ে, জোরে হলে সঙ্গে সঙ্গে কমে
                        if (peak > 40) {
                            val target = (26000f / peak).coerceIn(1f, maxGain)
                            gain = if (target < gain) target else gain + (target - gain) * 0.15f
                        }
                        val out = ByteArray(n * 2)
                        for (i in 0 until n) {
                            val v = (buf[i] * gain).toInt().coerceIn(-32768, 32767)
                            out[2 * i] = (v and 0xff).toByte()
                            out[2 * i + 1] = ((v shr 8) and 0xff).toByte()
                        }
                        raf.write(out); total += out.size
                    }
                    try { rec.stop() } catch (_: Exception) {}
                    rec.release()
                    val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                    b.put("RIFF".toByteArray()); b.putInt((36 + total).toInt()); b.put("WAVE".toByteArray())
                    b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
                    b.putInt(rate); b.putInt(rate * 2); b.putShort(2); b.putShort(16)
                    b.put("data".toByteArray()); b.putInt(total.toInt())
                    raf.seek(0); raf.write(b.array()); raf.close()
                }
            } finally {
                running = false
                @Suppress("DEPRECATION")
                audio.isSpeakerphoneOn = oldSpeaker
                audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL, oldVol, 0)
                // নম্বর না পেলে কল লগ থেকে নিয়ে ফাইলের নাম ঠিক করা
                main.postDelayed({ fixName(file, numberIn, incoming, time) }, 2500)
            }
        }.start()
    }

    private fun fixName(file: File, numberIn: String, incoming: Boolean, time: String) {
        if (numberIn.isNotEmpty() || !file.exists()) return
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME), null, null, "date DESC")?.use {
                if (it.moveToFirst()) {
                    val num = it.getString(0) ?: return
                    val name = it.getString(1) ?: contactName(num) ?: "Unknown"
                    file.renameTo(File(file.parentFile, fileName(name, num, incoming, time)))
                }
            }
        } catch (_: Exception) {}
    }

    private fun contactName(number: String): String? {
        if (number.isEmpty()) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) { null }
    }
}
